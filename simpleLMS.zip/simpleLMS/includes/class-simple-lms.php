<?php
/**
 * Main plugin class.
 *
 * @package SimpleLMS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Main Simple_LMS class.
 */
class Simple_LMS {

    /**
     * Single instance of the class.
     *
     * @var Simple_LMS
     */
    private static $instance = null;

    /**
     * Post types class instance.
     *
     * @var LMS_Post_Types
     */
    public $post_types;

    /**
     * Admin class instance.
     *
     * @var LMS_Admin
     */
    public $admin;

    /**
     * Access control class instance.
     *
     * @var LMS_Access_Control
     */
    public $access_control;

    /**
     * Templates class instance.
     *
     * @var LMS_Templates
     */
    public $templates;

    /**
     * Shortcodes class instance.
     *
     * @var LMS_Shortcodes
     */
    public $shortcodes;

    /**
     * Public class instance.
     *
     * @var LMS_Public
     */
    public $public;

    /**
     * Certificates class instance.
     *
     * @var LMS_Certificates
     */
    public $certificates;

    /**
     * Returns the single instance of the class.
     *
     * @return Simple_LMS
     */
    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->includes();
        $this->init_hooks();
    }

    /**
     * Include required files.
     */
    private function includes() {
        // Core classes.
        require_once SIMPLE_LMS_PLUGIN_DIR . 'includes/class-lms-course-data.php';
        require_once SIMPLE_LMS_PLUGIN_DIR . 'includes/class-lms-post-types.php';
        require_once SIMPLE_LMS_PLUGIN_DIR . 'includes/class-lms-access-control.php';
        require_once SIMPLE_LMS_PLUGIN_DIR . 'includes/class-lms-templates.php';
        require_once SIMPLE_LMS_PLUGIN_DIR . 'includes/class-lms-shortcodes.php';
        require_once SIMPLE_LMS_PLUGIN_DIR . 'includes/class-lms-certificates.php';

        // Admin classes.
        if ( is_admin() ) {
            require_once SIMPLE_LMS_PLUGIN_DIR . 'includes/class-lms-admin.php';
        }

        // Public classes.
        if ( ! is_admin() ) {
            require_once SIMPLE_LMS_PLUGIN_DIR . 'public/class-lms-public.php';
        }
    }

    /**
     * Initialize hooks.
     */
    private function init_hooks() {
        add_action( 'init', array( $this, 'init' ), 0 );
        add_action( 'admin_notices', array( $this, 'dependency_notices' ) );
        add_action( 'admin_bar_menu', array( $this, 'add_admin_bar_menu' ), 100 );
    }

    /**
     * Add admin bar menu items.
     *
     * This runs on both frontend and backend to show LMS quick links.
     *
     * @param WP_Admin_Bar $wp_admin_bar Admin bar object.
     */
    public function add_admin_bar_menu( $wp_admin_bar ) {
        if ( ! current_user_can( 'edit_posts' ) ) {
            return;
        }

        // Main LMS menu.
        $wp_admin_bar->add_node(
            array(
                'id'    => 'simple-lms',
                'title' => __( 'simpleLMS', 'simple-lms' ),
                'href'  => admin_url( 'admin.php?page=simple-lms' ),
            )
        );

        // Add New Course.
        $wp_admin_bar->add_node(
            array(
                'id'     => 'simple-lms-add',
                'parent' => 'simple-lms',
                'title'  => __( 'Add New Course', 'simple-lms' ),
                'href'   => admin_url( 'admin.php?page=simple-lms-add' ),
            )
        );

        // All Courses.
        $wp_admin_bar->add_node(
            array(
                'id'     => 'simple-lms-courses',
                'parent' => 'simple-lms',
                'title'  => __( 'All Courses', 'simple-lms' ),
                'href'   => admin_url( 'admin.php?page=simple-lms' ),
            )
        );

        // Edit current course (only on single course page - frontend).
        if ( ! is_admin() && is_singular( 'simple_lms_course' ) ) {
            $wp_admin_bar->add_node(
                array(
                    'id'     => 'simple-lms-edit',
                    'parent' => 'simple-lms',
                    'title'  => __( 'Edit This Course', 'simple-lms' ),
                    'href'   => admin_url( 'admin.php?page=simple-lms-add&course_id=' . get_the_ID() ),
                )
            );
        }
    }

    /**
     * Initialize classes on init.
     */
    public function init() {
        // Initialize post types and taxonomies.
        $this->post_types = new LMS_Post_Types();

        // Initialize access control.
        $this->access_control = new LMS_Access_Control();

        // Initialize templates.
        $this->templates = new LMS_Templates();

        // Initialize shortcodes.
        $this->shortcodes = new LMS_Shortcodes();

        // Initialize certificates.
        $this->certificates = new LMS_Certificates();

        // Initialize admin.
        if ( is_admin() ) {
            $this->admin = new LMS_Admin();
        }

        // Initialize public.
        if ( ! is_admin() ) {
            $this->public = new LMS_Public();
        }
    }

    /**
     * Display admin notices for missing dependencies.
     */
    public function dependency_notices() {
        // Check for WooCommerce.
        if ( ! class_exists( 'WooCommerce' ) ) {
            ?>
            <div class="notice notice-warning">
                <p><?php esc_html_e( 'simpleLMS: WooCommerce is not active. Some features may not work correctly.', 'simple-lms' ); ?></p>
            </div>
            <?php
        }

        // Check for WooCommerce Memberships.
        $has_memberships = function_exists( 'wc_memberships' );

        // Check for WooCommerce Subscriptions.
        $has_subscriptions = class_exists( 'WC_Subscriptions' );

        if ( ! $has_memberships && ! $has_subscriptions ) {
            ?>
            <div class="notice notice-info">
                <p><?php esc_html_e( 'simpleLMS: Neither WooCommerce Memberships nor WooCommerce Subscriptions is active. Access control features are disabled.', 'simple-lms' ); ?></p>
            </div>
            <?php
        }
    }

    /**
     * Get plugin settings.
     *
     * @param string $key Optional specific setting key.
     * @param mixed  $default Default value if key not found.
     * @return mixed
     */
    public static function get_setting( $key = null, $default = '' ) {
        $settings = get_option( 'simple_lms_settings', array() );

        if ( null === $key ) {
            return $settings;
        }

        return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
    }

    /**
     * Update plugin settings.
     *
     * @param string $key Setting key.
     * @param mixed  $value Setting value.
     */
    public static function update_setting( $key, $value ) {
        $settings         = get_option( 'simple_lms_settings', array() );
        $settings[ $key ] = $value;
        update_option( 'simple_lms_settings', $settings );
    }
}
