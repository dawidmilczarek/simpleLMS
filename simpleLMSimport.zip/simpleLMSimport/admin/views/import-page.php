<?php
/**
 * Import page view.
 *
 * @package SimpleLMS_Import
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$courses  = $this->get_old_courses();
$statuses = $this->get_available_statuses();
$count    = count( $courses );

// Messages.
$imported = isset( $_GET['imported'] ) ? intval( $_GET['imported'] ) : 0;
$errors   = isset( $_GET['errors'] ) ? intval( $_GET['errors'] ) : 0;
$error    = isset( $_GET['error'] ) ? sanitize_text_field( $_GET['error'] ) : '';
?>

<div class="wrap">
    <h1><?php esc_html_e( 'Import Courses from Course Manager', 'simple-lms' ); ?></h1>

    <?php if ( $imported > 0 ) : ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <?php
                printf(
                    /* translators: %d: number of imported courses */
                    esc_html__( 'Successfully imported %d courses.', 'simple-lms' ),
                    $imported
                );
                if ( $errors > 0 ) {
                    printf(
                        /* translators: %d: number of errors */
                        ' ' . esc_html__( '%d courses failed to import.', 'simple-lms' ),
                        $errors
                    );
                }
                ?>
            </p>
        </div>
    <?php endif; ?>

    <?php if ( $error === 'no_status' ) : ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e( 'Please select a status for imported courses.', 'simple-lms' ); ?></p>
        </div>
    <?php endif; ?>

    <div class="card" style="max-width: 100%; padding: 20px; margin-top: 20px;">
        <h2><?php esc_html_e( 'Import Summary', 'simple-lms' ); ?></h2>
        <p>
            <?php
            printf(
                /* translators: %d: number of courses */
                esc_html__( 'Found %d courses in Course Manager database.', 'simple-lms' ),
                $count
            );
            ?>
        </p>

        <?php if ( $count > 0 ) : ?>

            <?php if ( empty( $statuses ) ) : ?>
                <div class="notice notice-warning inline">
                    <p>
                        <?php esc_html_e( 'No statuses found in SimpleLMS. Please create at least one status in SimpleLMS settings before importing.', 'simple-lms' ); ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=simple-lms-settings&tab=statuses' ) ); ?>">
                            <?php esc_html_e( 'Go to Settings', 'simple-lms' ); ?>
                        </a>
                    </p>
                </div>
            <?php else : ?>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'simple_lms_import_action' ); ?>
                    <input type="hidden" name="action" value="simple_lms_import">

                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="import_status"><?php esc_html_e( 'Status for all imported courses', 'simple-lms' ); ?></label>
                            </th>
                            <td>
                                <select name="import_status" id="import_status" required>
                                    <option value=""><?php esc_html_e( '-- Select Status --', 'simple-lms' ); ?></option>
                                    <?php foreach ( $statuses as $status ) : ?>
                                        <option value="<?php echo esc_attr( $status->term_id ); ?>">
                                            <?php echo esc_html( $status->name ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">
                                    <?php esc_html_e( 'All imported courses will be assigned this status.', 'simple-lms' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>

                    <p>
                        <strong><?php esc_html_e( 'Data to import:', 'simple-lms' ); ?></strong>
                    </p>
                    <ul style="list-style: disc; margin-left: 20px;">
                        <li><?php esc_html_e( 'Course title', 'simple-lms' ); ?></li>
                        <li><?php esc_html_e( 'Lecturer (will be added to taxonomy if not exists)', 'simple-lms' ); ?></li>
                        <li><?php esc_html_e( 'Date', 'simple-lms' ); ?></li>
                        <li><?php esc_html_e( 'Time (start and end)', 'simple-lms' ); ?></li>
                        <li><?php esc_html_e( 'Duration', 'simple-lms' ); ?></li>
                        <li><?php esc_html_e( 'Videos (titles and links)', 'simple-lms' ); ?></li>
                        <li><?php esc_html_e( 'Materials (labels and links)', 'simple-lms' ); ?></li>
                    </ul>

                    <p class="submit">
                        <button type="submit" class="button button-primary button-large" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to import all courses? This action cannot be undone.', 'simple-lms' ); ?>');">
                            <?php
                            printf(
                                /* translators: %d: number of courses */
                                esc_html__( 'Import All %d Courses', 'simple-lms' ),
                                $count
                            );
                            ?>
                        </button>
                    </p>
                </form>

            <?php endif; ?>

            <hr style="margin: 30px 0;">

            <h3><?php esc_html_e( 'Preview: Courses to Import', 'simple-lms' ); ?></h3>

            <table class="wp-list-table widefat fixed striped" style="margin-top: 15px;">
                <thead>
                    <tr>
                        <th style="width: 30%;"><?php esc_html_e( 'Title', 'simple-lms' ); ?></th>
                        <th style="width: 15%;"><?php esc_html_e( 'Lecturer', 'simple-lms' ); ?></th>
                        <th style="width: 12%;"><?php esc_html_e( 'Date', 'simple-lms' ); ?></th>
                        <th style="width: 10%;"><?php esc_html_e( 'Time', 'simple-lms' ); ?></th>
                        <th style="width: 8%;"><?php esc_html_e( 'Duration', 'simple-lms' ); ?></th>
                        <th style="width: 12%;"><?php esc_html_e( 'Videos', 'simple-lms' ); ?></th>
                        <th style="width: 13%;"><?php esc_html_e( 'Materials', 'simple-lms' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $courses as $course ) : ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html( $course['title'] ); ?></strong>
                            </td>
                            <td><?php echo esc_html( $course['trainer_name'] ); ?></td>
                            <td><?php echo esc_html( $course['original_date'] ); ?></td>
                            <td><?php echo esc_html( $course['original_time'] ); ?></td>
                            <td><?php echo esc_html( $course['duration'] ); ?></td>
                            <td>
                                <?php
                                $video_count = is_array( $course['video_links'] ) ? count( $course['video_links'] ) : 0;
                                printf(
                                    /* translators: %d: number of videos */
                                    esc_html( _n( '%d video', '%d videos', $video_count, 'simple-lms' ) ),
                                    $video_count
                                );
                                ?>
                            </td>
                            <td>
                                <?php
                                $material_count = is_array( $course['training_material_links'] ) ? count( $course['training_material_links'] ) : 0;
                                printf(
                                    /* translators: %d: number of materials */
                                    esc_html( _n( '%d material', '%d materials', $material_count, 'simple-lms' ) ),
                                    $material_count
                                );
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        <?php else : ?>
            <p><?php esc_html_e( 'No courses found to import.', 'simple-lms' ); ?></p>
        <?php endif; ?>
    </div>
</div>
